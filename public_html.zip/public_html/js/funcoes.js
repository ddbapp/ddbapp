function teste(){
    location.href = "index.html#inicio";
}